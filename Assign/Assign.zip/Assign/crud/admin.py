from django.contrib import admin
from crud.models import Contact

# Register your models here.
admin.site.register(Contact)

# Register your models here.
