from django.shortcuts import render
from datetime import datetime
from crud.models import Contact
from django.contrib import messages

# Create your views here.

def index(request):
    return render(request,'home.html')
def page(request):
    return render(request,'page.html')
def team(request):
    return render(request,'team.html')
def crud(request):
    if request.method == "POST":
        name = request.POST.get('name')
        position = request.POST.get('position')
        motivation = request.POST.get('motivation')
        date = datetime.today()
        Contact.objects.save(name=name, position=position,motivation=motivation)
        messages.success(request, 'Your message has been sent!')
    return render(request,'crud.html')



def data(request):
    contact = Contact.objects.all()
    context = {
        'contact': contact
    }
    return render(request,'crud_index.html', context)

def add(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        position = request.POST.get('position')
        motivation = request.POST.get('motivation')
        contact = Contact(name=name, position=position,motivation=motivation)
        contact.save()
        # return redirect('crud_index.html')
    return render(request,'crud_index.html')

# def edit(request):
#     contact=Contact.objects.all()
#     context={
#         'contact':contact
#     }
#     return render(request,'crud_index.html')

# def update(request):
#     if request.method == "POST":
#         id=id
#         name = request.POST.get('name')
#         position = request.POST.get('position')
#         motivation = request.POST.get('motivation')
#         contact = Contact(name=name, position=position,motivation=motivation)
#         Contact.save()
#     return render(request,'crud_index.html')

# def delete(request):
#     con=Contact.object.filter(id=id)
#     return render(request,'crud_index.html')
