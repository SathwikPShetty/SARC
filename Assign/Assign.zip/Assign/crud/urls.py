from django.contrib import admin
from django.urls import path
from crud import views

urlpatterns = [
    path('',views.index,name='home'),
    path('crud/',views.crud,name='crud'),
    path('data/',views.data,name='data'),
    path('page/',views.page,name='page'),
    path('page/team/',views.team,name='team'),
    path('/add',views.add,name='add'),
    # path('/edit',views.edit,name='edit'),
    # path('update/<str.id>',views.update,name='update'),
    # path('delete/<str.id>',views.delete,name='delete'),
]