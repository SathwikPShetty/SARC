import datetime
from django.db import models
from django.utils import timezone
# from .models import Contacts

class Contact(models.Model):
    name = models.CharField(max_length=100,null=True)
    position= models.TextField(null=True)
    motivation= models.TextField(max_length=100,null=True)
    date=models.DateField(default=timezone.now, blank=True)

    def __str__(self):
        return self.name
